// Propable Interface
//51422107 Ncube NM
//53546407 Moraba L
interface Propable {
    public double calcMonthRent();
}